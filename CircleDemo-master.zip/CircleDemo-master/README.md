# CircleDemo
仿微信实现的朋友圈，模拟与后台交互实现了点赞、评论、删除等功能，RecyclerView可以根据键盘的显示或隐藏实现联动。
增加短视频拍摄功能（趣拍标准版SDK）
与后台交互采用mvp模式。

图片显示规则类似微信朋友圈的排列

有问题请加QQ群：457022718


##TODO
1.列表加入短视频，如微信<br>


## 贡献者
16/02/26<br>
非常感谢[hnclca](https://github.com/hnclca)增加图片点击效果，修改单张图片样式





##效果图
![image](https://github.com/Naoki2015/CircleDemo/blob/master/CircleDemo/imgs/1.png)
![image](https://github.com/Naoki2015/CircleDemo/blob/master/CircleDemo/imgs/2.png)
![image](https://github.com/Naoki2015/CircleDemo/blob/master/CircleDemo/imgs/3.png)
