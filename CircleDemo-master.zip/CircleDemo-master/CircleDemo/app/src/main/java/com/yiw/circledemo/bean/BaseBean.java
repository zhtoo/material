package com.yiw.circledemo.bean;

import java.io.Serializable;
/**
 * 
* @ClassName: BaseBean 
* @Description: TODO(这里用一句话描述这个类的作用) 
* @author yiw
* @date 2015-12-28 下午3:44:29 
*
 */
public class BaseBean implements Serializable{

	private static final long serialVersionUID = 1L;

}
