package com.yiw.circledemo.listener;

/**
 * Created by yiwei on 16/4/9.
 */
public interface RecycleViewItemListener {

    void onItemClick(int position);
    boolean onItemLongClick(int position);
}
