package com.yiw.circledemo.bean;

/**
 * Created by suneee on 2016/11/17.
 */
public class PhotoInfo {

    public String url;
    public int w;
    public int h;
}
