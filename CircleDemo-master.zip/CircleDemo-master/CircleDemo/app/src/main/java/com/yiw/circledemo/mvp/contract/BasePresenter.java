package com.yiw.circledemo.mvp.contract;

/**
 * Created by suneee on 2016/7/15.
 */
public interface BasePresenter {
}
