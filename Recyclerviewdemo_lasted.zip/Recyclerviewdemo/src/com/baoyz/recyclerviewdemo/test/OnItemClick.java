package com.baoyz.recyclerviewdemo.test;

import android.view.View;

/**
 * Created by dsw on 2015/10/2.
 */
public interface OnItemClick {
    public void onItemClick(View view,int position);
}
