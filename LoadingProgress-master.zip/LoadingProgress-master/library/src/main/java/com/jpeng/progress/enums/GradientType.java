package com.jpeng.progress.enums;

/**
 * Created by peng on 16-10-23.
 */
public enum GradientType {
        LINEAR,SWEEP;
}
