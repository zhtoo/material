package com.jpeng.progress.enums;

/**
 * Created by peng on 16-10-18.
 *
 */
public enum CircleStyle {
	RING, FAN
}
