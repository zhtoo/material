# TaoBaoUI
自己写的高仿淘宝界面(非常适合新手学习)，
使用了RecyclerView，用RecyclerView的多条目布局做的，里面使用了一些自定义组件，可以学习到自定义属性的编写。里面还有一些工具性的东西，可以拿到你自己的项目中改改就用（懒人必备）

## 可以学习到：

- RecyclerView的多条目布局，使用RecyclerView做	addHeaderView,addFooterView，以及RecyclerView的基本使用

- 基本的自定义控件，自定义属性的编写，

- 学习使用include,merge对布局进行优化

##可以收获：
- 一些工具性质的组件，比如轮播图，可以直接拿去你的项目中改改就能用（懒人必备）

##效果图
![](https://raw.githubusercontent.com/gnehsuy/TaoBaoUI/master/Images/Screenshot_2016-11-30-14-36-29_com.yus.taobaoui.png)

![](https://raw.githubusercontent.com/gnehsuy/TaoBaoUI/master/Images/Screenshot_2016-11-30-14-37-56_com.yus.taobaoui.png)


