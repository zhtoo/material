package me.leefeng.citypicker;

/**
 * Created by limxing on 2016/10/9.
 */

public interface JavaScriptListener {
    void cancle();
    void city(String name);
}
