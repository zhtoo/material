package me.leefeng.citypicker;

/**
 * Created by limxing on 2016/10/9.
 */

public interface CityPickerListener {
    void getCity(String name);
}
