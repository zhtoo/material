GreenDao Demo
====================
###1. Demo Download
<a href="apk/greendao-demo.apk?raw=true" target="_blank" title="点击下载到本地">本地下载</a>  
###2. Screenshot
![Screenshot](apk/greendao-demo.gif)  

