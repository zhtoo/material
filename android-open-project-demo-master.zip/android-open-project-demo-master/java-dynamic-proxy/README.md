Java Dynamic Proxy Demo
====================
###1. Demo Download
[Run Main](https://github.com/android-cn/android-open-project-demo/blob/master/java-dynamic-proxy/src/com/codekk/java/test/dynamicproxy/Main.java)  

###1. View Class File
运行 [Main](https://github.com/android-cn/android-open-project-demo/blob/master/java-dynamic-proxy/src/com/codekk/java/test/dynamicproxy/Main.java) 函数，会将动态代理生成的代理类代码保存在项目根目录下`$Proxy0.class`文件内，`$Proxy0.class` 查看可使用 [jd-gui](http://jd.benow.ca/#jd-gui-download)  