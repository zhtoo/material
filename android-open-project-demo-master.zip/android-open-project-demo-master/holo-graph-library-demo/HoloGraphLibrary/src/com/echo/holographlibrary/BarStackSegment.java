package com.echo.holographlibrary;

/**
 * Created by Aaron on 19/10/2014.
 */
public class BarStackSegment {
    public int Value;
    public int Color;
    public BarStackSegment(int val, int color){
        Value = val;
        Color = color;
    }
}
