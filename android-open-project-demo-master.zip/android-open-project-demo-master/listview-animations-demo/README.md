ListviewAnimation demo实例  
本工程为Eclipse工程   
文件夹说明如下  
--ListviewAnimationDemo Demo工程  
--ListviewAnimationLib	依赖库  
--apk demo工程生成的apk  

原理分析[https://github.com/android-cn/android-open-project-analysis/tree/master/listview-animations](https://github.com/android-cn/android-open-project-analysis/tree/master/listview-animations)