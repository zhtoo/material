DataDroid Demo
====================
###1. Demo Download
[Click to download](https://github.com/android-cn/android-open-project-demo/blob/master/dataddroid-demo/apk/DataddroidDemo.apk?raw=true)

###2. Screenshot
![Screenshot](apk/loading.png)   
![Screenshot](apk/load-done.png)    

###3. Document
[How to Use DataDroid](https://github.com/android-cn/android-open-project-analysis/tree/master/datadroid)  
