<img src="https://raw.githubusercontent.com/android-cn/android-open-project-demo/master/android-view-hover-demo/screenshots/s1.png" alt="screenshot" title="screenshot" width="270" height="486" />

by [drakeet](https://github.com/drakeet)