EventBus Demo
====================
###1. Demo Download
[Google Play 下载](https://play.google.com/store/apps/details?id=cn.trinea.android.demo.eventbus "从Google Play下载")  
[本地下载](apk/event-bus-demo.apk?raw=true "点击下载到本地")  

###2. Screenshot
![Screenshot](apk/event-bus-demo.gif)  

###3. Document
[How to Use EventBus](https://github.com/greenrobot/EventBus/blob/master/HOWTO.md)  
