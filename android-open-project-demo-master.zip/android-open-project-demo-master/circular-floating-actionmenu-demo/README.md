Circular Floating Action Menu Demo
================================
一个与`Path`菜单类似的(非完整)圆形弹出菜单，可方便的定制菜单以及动画。  
###1. Demo Download
[本地下载](https://github.com/android-cn/android-open-project-demo/tree/master/circular-floating-actionmenu-demo/apk)

###2. Screenshot
![Screenshot](apk/demo.gif)
