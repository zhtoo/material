#Discrete-Seek-Bar-Demo

====================
###1. Original Project
[AnderWeb/discreteSeekBar](https://github.com/AnderWeb/discreteSeekBar)

###2. Demo
[local demo download](apk/discrete-seek-bar-demo.apk?raw=true "click to download")  

###3. Screenshot
![Screenshot](apk/discreteseekbar.gif)  


