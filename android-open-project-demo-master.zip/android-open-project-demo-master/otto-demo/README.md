Otto Demo
====================
###1. Demo Download
    <a href="apk/otto-demo.apk?raw=true" target="_blank" title="点击下载到本地">本地下载</a>  
###2. Screenshot
![Screenshot](apk/otto_demo.gif)  
###3. Document
[How to Use Otto](http://square.github.io/otto/)  
