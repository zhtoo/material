package model.event;

/**
 * Created by PromeG on 2014/7/8.
 */
public class GetInfoEvent {

}
