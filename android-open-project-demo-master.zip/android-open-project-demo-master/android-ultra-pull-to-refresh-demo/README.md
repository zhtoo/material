UltraPTR Demo
================================
###1.Demo Download
[本地下载](./apk/UltraPTR-demo.apk?raw=true)

###2.Screenshot
####包含内容
![TextView](image/content_text_view.gif)![ImageView](image/content_image_view.gif)![ScrollView](image/content_scroll_view.gif)![ListView](image/content_list_view.gif)![GridView](image/content_grid_view.gif)![WebView](image/content_web_view.gif)![RecyclerView](image/content_recycler_view.gif)  
####刷新类型 
![ReleaseToRefresh](image/release_to_refresh.gif)![PullToRefresh](image/pull_to_refresh.gif)![AutoRefresh](image/auto_refresh.gif)
####头部  
![StoreHouseHeader](image/store_house_header.gif)![MaterialHeader](image/material_header.gif)![CustomHeader](image/custom_header.gif)
####自定义加载更多  
![GetMoreListView](image/get_more_list_view.gif)
