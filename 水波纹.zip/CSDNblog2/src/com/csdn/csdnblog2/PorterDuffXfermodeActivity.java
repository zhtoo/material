package com.csdn.csdnblog2;

import android.app.Activity;
import android.os.Bundle;
/**
 * @author tianjian 
 * @created 2015/2/2
 */
public class PorterDuffXfermodeActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.porter_duff_xfermode_layout);
    }
}
